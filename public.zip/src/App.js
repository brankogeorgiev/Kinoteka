import "./App.css";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import HomePage from "./pages/HomePage";
import RootLayout from "./pages/Root";
import AuthenticationPage from "./pages/Authentication";
import MoviesRootLayout from "./pages/MoviesRoot";
import MoviesPage from "./pages/Movies";
import { loader as moviesLoader } from "./pages/Movies";
import MovieDetailPage, {
  loader as movieDetailLoader,
} from "./pages/MovieDetail";

const router = createBrowserRouter([
  {
    path: "/",
    element: <RootLayout />,
    id: "root",
    children: [
      { index: true, element: <HomePage /> },
      {
        path: "auth",
        element: <AuthenticationPage />,
      },
      {
        path: "movies",
        element: <MoviesRootLayout />,
        children: [
          {
            index: true,
            element: <MoviesPage />,
            loader: moviesLoader,
          },
          {
            path: ":movieId",
            id: "movie-detail",
            loader: movieDetailLoader,
            children: [
              {
                index: true,
                element: <MovieDetailPage />,
              },
            ],
          },
        ],
      },
    ],
  },
]);

function App() {
  return <RouterProvider router={router} />;
}

export default App;
