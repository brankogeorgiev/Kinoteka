import { Outlet } from "react-router-dom";

function MoviesRootLayout() {
  return (
    <>
      <Outlet />
    </>
  );
}

export default MoviesRootLayout;
