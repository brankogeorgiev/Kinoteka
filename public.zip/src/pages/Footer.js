function Footer() {}

export default Footer;
