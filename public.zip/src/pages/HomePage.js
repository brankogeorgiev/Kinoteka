import Header from "./Header";
import MainContent from "./MainContent";

function HomePage() {
  return (
    <>
      <div
        style={{
          backgroundColor: "var(--color-secondary)",
          padding: "0 0 2.5rem 0",
        }}
      >
        <MainContent />
      </div>
    </>
  );
}

export default HomePage;
