import { useState } from "react";
import { GrNext, GrPrevious } from "react-icons/gr";
import classes from "./Carousel.module.css";

function Carousel({ images }) {
  const [activeIndex, setActiveIndex] = useState(0);
  let intervalTime = 10000;

  function prevSlide() {
    setActiveIndex((prevIndex) =>
      prevIndex === 0 ? images.length - 1 : prevIndex - 1
    );
  }

  function nextSlide() {
    setActiveIndex((prevIndex) =>
      prevIndex === images.length - 1 ? 0 : prevIndex + 1
    );
  }

  //   const timer = setInterval(() => {
  //     nextSlide();
  //   }, intervalTime);

  return (
    <div className={classes.carousel_container}>
      <div className={classes.carousel}>
        <div onClick={prevSlide} className={classes.carousel_btn_prev}>
          <div>
            <GrPrevious className={classes.carousel_btn_icon} />
          </div>
        </div>
        <img
          src={images[activeIndex]}
          className={classes.carousel_img}
          alt={`Slide ${activeIndex}`}
        ></img>
        <div onClick={nextSlide} className={classes.carousel_btn_next}>
          <div>
            <GrNext className={classes.carousel_btn_icon} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Carousel;
