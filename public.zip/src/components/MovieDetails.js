import { useEffect } from "react";
import classes from "./MovieDetails.module.css";

function MovieDetails({ movie }) {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  console.log(movie);

  return (
    <>
      <div className={classes.movie_details_container}>
        <div className={classes.movie_details}>
          <div className={classes.row}>
            <h1>Movie Title {movie.title}</h1>
          </div>
          <div className={classes.row}>
            <iframe
              src={movie.trailer}
              title="YouTube video player"
              frameborder="0"
              allow="fullscreen; accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowfullscreen
              webkitallowfullscreen
            ></iframe>
          </div>
          <div className={classes.row}>
            <img src={movie.poster} />
            <div className={classes.movie_informations}>
              <div className={classes.movie_label}>
                <div>Movie Author:</div> {movie.author}
              </div>
              <div className={classes.movie_label}>
                <div>Movie Duration:</div> {movie.durationTime} min
              </div>
              <div className={classes.movie_label}>
                <div>Movie Description:</div> {movie.description}
              </div>
              <div className={classes.movie_label}>
                <div>Actors:</div> {movie.actors.join(", ")}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default MovieDetails;
