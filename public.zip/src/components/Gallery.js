import classes from "./Gallery.module.css";
import { Link } from "react-router-dom";

const movies = [
  {
    id: 1,
    title: "Madame Web",
    url: "https://lh3.googleusercontent.com/proxy/0zqRTMqdNU2aA2zdo7PPYNUT4C9k0zMpcuHxQ8dvYpYif2QPTlUsp-VU_Or_SPqP0y6v6MhB7_EjntbOqi0q5oWb68RR688",
    author: "Author 1",
    durationTime: 120,
    actors: ["Actor 1", "Actor 2"],
    description: "Lorem ipsum description 1",
  },
  {
    id: 2,
    title: "Beekeeper",
    url: "https://m.media-amazon.com/images/M/MV5BZjQwYjU3OTYtMWVhMi00N2Y2LWEzMDgtMzViN2U4NWI1NmI3XkEyXkFqcGdeQXVyODk2NDQ3MTA@._V1_FMjpg_UX1000_.jpg",
    author: "Author 2",
    durationTime: 120,
    actors: ["Actor 3", "Actor 4"],
    description: "Lorem ipsum description 2",
  },
];

function Gallery() {
  return (
    <>
      <div className={classes.gallery}>
        <h1>Top picks</h1>
        <div className={classes.gallery_images}>
          <div className={classes.row}>
            <div className={classes.group}>
              <Link to={`/movies/${movies[0].id}`}>
                <img src={movies[0].url}></img>
              </Link>
            </div>
            <div className={classes.group}>
              <div>
                <div className={classes.group_m}>
                  <Link to={`/movies/${movies[1].id}`}>
                    <img src={movies[1].url}></img>
                  </Link>
                </div>
                <div className={classes.group_m}>
                  <Link to={`/movies/${movies[1].id}`}>
                    <img src={movies[1].url}></img>
                  </Link>
                </div>
              </div>
              <div className={classes.group_m}>
                <Link to={`/movies/${movies[1].id}`}>
                  <img src={movies[1].url}></img>
                </Link>
              </div>
              <div className={classes.group_m}>
                <Link to={`/movies/${movies[1].id}`}>
                  <img src={movies[1].url}></img>
                </Link>
              </div>
            </div>
          </div>
          <div className={classes.row}>
            <div className={classes.group}>
              <div>
                <div className={classes.group_m}>
                  <Link to={`/movies/${movies[1].id}`}>
                    <img src={movies[1].url}></img>
                  </Link>
                </div>
                <div className={classes.group_m}>
                  <Link to={`/movies/${movies[1].id}`}>
                    <img src={movies[1].url}></img>
                  </Link>
                </div>
              </div>
              <div className={classes.group_m}>
                <Link to={`/movies/${movies[1].id}`}>
                  <img src={movies[1].url}></img>
                </Link>
              </div>
              <div className={classes.group_m}>
                <Link to={`/movies/${movies[1].id}`}>
                  <img src={movies[1].url}></img>
                </Link>
              </div>
            </div>
            <div className={classes.group}>
              <Link to={`/movies/${movies[0].id}`}>
                <img src={movies[0].url}></img>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Gallery;
